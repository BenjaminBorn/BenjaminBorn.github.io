function [w, Y1, Y1_synth] = find_synthetic_control_revised(treatment_country, data_treat, data_info, optim_choice, ...
    covariate_dum,mean_dum,mean_cov,outer_loop,data_treat_long,data_cov_long,n_cov)

treatment_date  = data_info.treatment_date;
timeline        = data_info.timeline;
country_names   = data_info.country_names;
n_predict       = data_info.n_predict;
n_outcome       = data_info.n_outcome;
n_countries     = data_info.n_countries;

if ~strcmp(treatment_country, 'United Kingdom')
    uk_entry = find(strcmp(country_names(1, :), 'United Kingdom'));
    country_names(uk_entry) = [];
    data_treat(:, uk_entry) = [];
    n_countries = n_countries - 1;
    mean_cov(:, uk_entry) = [];
end


%% Built Indices

% Find the entry for the treatment country
index_tr  = find(strcmp(country_names(1,:),treatment_country));
% control countries
index_co = (1:n_countries)';
index_co(index_tr) = [];

%% Define matrices for matching in inner loop using all covariates
if covariate_dum
    if mean_dum
        X0 = [data_treat(:, index_co); mean_cov(:, index_co)];
        X1 = [data_treat(:, index_tr); mean_cov(:, index_tr)];
    else
        % X0 : covariates of control countries
        X0 = data_cov(:, index_co, :);
        
        % X1 : covariates of treatment country
        X1 = data_cov(:, index_tr, :);
        
        % include "lags" of treatment variable
        X0 = cat(3, data_treat(:, index_co), X0);
        X1 = cat(3, data_treat(:, index_tr), X1);
        
        % stack everything in 2d
        splitX0 = num2cell(X0, [1 2]); %split X0 keeping dimension 1 and 2 intact
        X0 = vertcat(splitX0{:}); % stack
        X1 = X1(:);
    end
else
    % include "lags" of treatment variable
    X0 = data_treat(:, index_co);
    X1 = data_treat(:, index_tr);
end

%% Define Matrices for outer loop optimization

% Now pick Z matrices, i.e. the pretreatment period
% over which the loss function should be minimized

if outer_loop
    % output only
    Z0 = data_treat(:, index_co);
    Z1 = data_treat(:, index_tr);
else
    % all observables
    Z0 = X0;
    Z1 = X1;
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Optimization
options = optimset('MaxFunEvals', 100000, 'Display', 'iter', 'MaxIter', 100000, 'TolFun', 1e-11, 'TolX', 1e-3);

% Get Starting Values 
s = std([X1 X0],[],2);
s1 = s(1);
s2 = s(2:end);
v20 =((s1./s2).^2);
        
switch optim_choice
    case 1
        v20 = log(v20); %transform to unconstrained domain
        [v2,fminv,exitflag] = fminsearch('loss_function_transformed',v20,options,X1,X0,Z1,Z0);
        % V-weights
        v = [1;exp(v2)]; % retransform
    case 2
        v20 = log(v20); %transform to unconstrained domain
        % set csminwel options
        H0 = 1e-2*eye(length(v20)); %Initial Hessian
        crit = 1e-8; %Tolerance
        nit = 1000;  %Number of iterations
        
        [fminv,v2] = csminwel(@loss_function_transformed,v20,H0,[],crit,nit,X1,X0,Z1,Z0);
        % V-weights
        v = [1;exp(v2)]; % retransform
    case 3
        options = optimset('fmincon');
        [v2,fminv,exitflag] = fmincon('loss_function',v20,[],[],[],[],...
            zeros(size(X1)-1),[],[],options,X1,X0,Z1,Z0);
        % V-weights
        v = [1;v2];
    case 4
        v20 = log(v20); %transform to unconstrained domain
        % set csminwel options
        H0 = 1e-2*eye(length(v20)); %Initial Hessian
        crit = 1e-8; %Tolerance
        nit = 10000;  %Number of iterations
        
        [fminv1,v2] = csminwel(@loss_function_transformed,v20,H0,[],crit,nit,X1,X0,Z1,Z0);
        % V-weights
        % v = [1;exp(v2)]; % retransform
        fprintf('%15.4f',fminv1);
        
        % v20 = log(v); %transform to unconstrained domain
        [v22,fminv,exitflag] = fminsearch('loss_function_transformed',v2,options,X1,X0,Z1,Z0);
        % V-weights
        v = [1;exp(v22)]; % retransform
end
fprintf('%15.4f',fminv);

% Now recover W-weights
D = diag(v);
H = X0'*D*X0;
H = (H+H')/2;
f = - X1'*D*X0;
options = optimoptions('quadprog', 'Display', 'off');
[w,fval,e]=quadprog(H,f,[],[],ones(1,size(X0,2)),1,zeros(size(X0,2),1),ones(size(X0,2),1),[],options);
w = abs(w);

%% plot preparations

% data including post-vote sample
if covariate_dum
    Y0 = cat(3, data_treat_long(:, index_co), data_cov_long(:, index_co, :));
    Y1 = squeeze(cat(3, data_treat_long(:, index_tr), data_cov_long(:, index_tr, :)));
    
    if mean_dum
        Y0_means = mean_cov(:, index_co);
        Y1_means = mean_cov(:, index_tr);
        Y0_means_comb = Y0_means * w;
    end

else
    Y0 = data_treat_long(:, index_co);
    Y1 = data_treat_long(:, index_tr);
end
Y0_comb = NaN(size(Y0, 1), n_cov + 1);
for ii = 1:n_cov + 1
    Y0_comb(:, ii) = Y0(:, :, ii) * w;
end
diff_mat = Y1 - Y0_comb;

% save output for VARs and robustness
Y1_synth = Y0_comb(:,1);


end