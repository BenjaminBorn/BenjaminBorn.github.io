run('SCM_lockdown_Baseline_Infections.m')
close all;
activity = {'Grocery','Parks','Residential','Retail','Transit','Work'}; 

figure

plot_end   = datenum('01-sep-20','dd-mmm-yy')

for ii = 1:6
    name=char(activity(ii));
    locationdata_raw = xlsread(['../../data/2904/', activity{1,ii}, '.xlsx'],1,'B2:AD220');
    locationdata = locationdata_raw(:, country_select);
    if ~isempty(missing_something)
        locationdata(:, missing_something) = [];
    end
    locationdata = fillmissing(locationdata,'linear',2);
    
    location_sweden = 1/11*(locationdata(:, index_tr)+lagmatrix(locationdata(:, index_tr),1)+lagmatrix(locationdata(:, index_tr),-1)+lagmatrix(locationdata(:, index_tr),2)+lagmatrix(locationdata(:, index_tr),-2)+lagmatrix(locationdata(:, index_tr),3)+lagmatrix(locationdata(:, index_tr),-3)+lagmatrix(locationdata(:, index_tr),4)+lagmatrix(locationdata(:, index_tr),-4)+lagmatrix(locationdata(:, index_tr),5)+lagmatrix(locationdata(:, index_tr),-5));
    location_doppel = 1/11*(locationdata(:, index_co)*w+lagmatrix(locationdata(:, index_co)*w,1)+lagmatrix(locationdata(:, index_co)*w,-1)+lagmatrix(locationdata(:, index_co)*w,2)+lagmatrix(locationdata(:, index_co)*w,-2)+lagmatrix(locationdata(:, index_co)*w,3)+lagmatrix(locationdata(:, index_co)*w,-3)+lagmatrix(locationdata(:, index_co)*w,4)+lagmatrix(locationdata(:, index_co)*w,-4)+lagmatrix(locationdata(:, index_co)*w,5)+lagmatrix(locationdata(:, index_co)*w,-5));

    time=timeline_dates(1:length(location_sweden));
    figure(ii)
    ha=plot(time, location_sweden, 'b-', time, location_doppel, 'r--', 'LineWidth', 1.5); hold on;
    xticks([datenum(2020,03,1) datenum(2020,04,1)...
    datenum(2020,05,1) datenum(2020,06,01) ...
    datenum(2020,07,01)  datenum(2020,08,01)...
    datenum(2020,09,01) datenum(2020,10,01)]);
    datetick('x','dd.mmm','keepticks')
    
    xlim([timeline_dates(plot_start), plot_end])
     
    ylim([min(min(location_sweden, location_doppel))-5, max(max(location_sweden, location_doppel))+5]);
    patch([timeline_dates(1)+average_lockdown_date timeline_dates(1)+average_lockdown_end_date timeline_dates(1)+average_lockdown_end_date timeline_dates(1)+average_lockdown_date], [min(ylim) min(ylim) max(ylim) max(ylim)],[1 0 0],'EdgeColor','none','FaceAlpha',.05);

    ylabel('index')
    if ii == 6
        legend(ha,'Sweden', 'Counterfactual', 'Location', 'northeast');
        legend box off
    end

    set(gca,'Layer','top')
    
   fig=gcf;
   set(gca,'FontSize',20);
 
   print(gcf, ['../../Code_Final/Figures/Google_Mobility/MA_',name,'.pdf'], '-bestfit', '-dpdf') 
    
end
