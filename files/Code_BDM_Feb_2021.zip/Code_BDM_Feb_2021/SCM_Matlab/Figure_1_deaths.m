clear all; close all;
run('SCM_lockdown_Baseline_Deaths.m')
run('SCM_lockdown_Baseline_Deaths_R1.m')
run('SCM_lockdown_Baseline_Deaths_R2.m')
run('SCM_lockdown_Baseline_placebo_Deaths.m')
run('SCM_lockdown_robustness_Deaths.m')
%%
countryex=[ 2 4 12];

load('Robustness_Results')
load('Sweden_Excess_Deaths_Baseline_D')
Sweden_D=Sweden;
Counterfactual_D=Counterfactual;
load('Sweden_Excess_Infections_Baseline_D')
Sweden_I=Sweden;
Counterfactual_I=Counterfactual;

load('Sweden_Excess_Deaths_R1_D')
Sweden_D_R1=Sweden;
Counterfactual_D_R1=Counterfactual;
load('Sweden_Excess_Infections_R1_D')
Sweden_I_R1=Sweden;
Counterfactual_I_R1=Counterfactual;

load('Sweden_Excess_Deaths_R2_D')
Sweden_D_R2=Sweden;
Counterfactual_D_R2=Counterfactual;
load('Sweden_Excess_Infections_R2_D')
Sweden_I_R2=Sweden;
Counterfactual_I_R2=Counterfactual;

robustness_doppelganger(robustness_doppelganger==0) = NaN;
robustness_doppelganger_infections(robustness_doppelganger_infections==0) = NaN;
robustness_Sweden(robustness_Sweden==0) = NaN;
robustness_Sweden_infections(robustness_Sweden_infections==0) = NaN;
robustness_doppelganger=robustness_doppelganger(:,countryex);
robustness_doppelganger_infections=robustness_doppelganger_infections(:,countryex);
robustness_Sweden=robustness_Sweden(:,countryex);
robustness_Sweden_infections=robustness_Sweden_infections(:,countryex);
%%
Counterfactual_Deaths_Level=(Counterfactual_D);
Sweden_Deaths_Level=(Sweden_D);

Counterfactual_Infections_Level=(Counterfactual_I);
Sweden_Infections_Level=(Sweden_I);

Counterfactual_Deaths_Level_R1=(Counterfactual_D_R1);
Sweden_Deaths_Level_R1=(Sweden_D_R1);

Counterfactual_Infections_Level_R1=(Counterfactual_I_R1);
Sweden_Infections_Level_R1=(Sweden_I_R1);

Counterfactual_Deaths_Level_R2=(Counterfactual_D_R2);
Sweden_Deaths_Level_R2=(Sweden_D_R2);

Counterfactual_Infections_Level_R2=(Counterfactual_I_R2);
Sweden_Infections_Level_R2=(Sweden_I_R2);

b =robustness_doppelganger(any(robustness_doppelganger ~= NaN,2),:);
R_Deaths_C =(b(:,any(b ~= NaN,1)));

b =robustness_doppelganger_infections(any(robustness_doppelganger_infections ~= NaN,2),:);
R_Infections_C =(b(:,any(b ~= NaN,1)));

b =robustness_Sweden(any(robustness_Sweden ~= NaN,2),:);
R_Deaths_S =(b(:,any(b ~= NaN,1)));

b =robustness_Sweden_infections(any(robustness_Sweden_infections ~= NaN,2),:);
R_Infections_S =(b(:,any(b ~= NaN,1)));

%%  Absolute Numbers since Start of Lockdown

S_Deaths_Since_L=Sweden_Deaths_Level-Sweden_Deaths_Level(1);
C_Deaths_Since_L=Counterfactual_Deaths_Level-Counterfactual_Deaths_Level(1);

S_Infections_Since_L=Sweden_Infections_Level-Sweden_Infections_Level(1);
C_Infections_Since_L=Counterfactual_Infections_Level-Counterfactual_Infections_Level(1);

S_Deaths_Since_L_R1=Sweden_Deaths_Level_R1-Sweden_Deaths_Level_R1(1);
C_Deaths_Since_L_R1=Counterfactual_Deaths_Level_R1-Counterfactual_Deaths_Level_R1(1);

S_Infections_Since_L_R1=Sweden_Infections_Level_R1-Sweden_Infections_Level_R1(1);
C_Infections_Since_L_R1=Counterfactual_Infections_Level_R1-Counterfactual_Infections_Level_R1(1);

S_Deaths_Since_L_R2=Sweden_Deaths_Level_R2-Sweden_Deaths_Level_R2(1);
C_Deaths_Since_L_R2=Counterfactual_Deaths_Level_R2-Counterfactual_Deaths_Level_R2(1);

S_Infections_Since_L_R2=Sweden_Infections_Level_R2-Sweden_Infections_Level_R2(1);
C_Infections_Since_L_R2=Counterfactual_Infections_Level_R2-Counterfactual_Infections_Level_R2(1);

R_Deaths_C_Since_L=R_Deaths_C-R_Deaths_C(1,:);
R_Infections_C_Since_L=R_Infections_C-R_Infections_C(1,:);

R_Deaths_S_Since_L=R_Deaths_S-R_Deaths_S(1,:);
R_Infections_S_Since_L=R_Infections_S-R_Infections_S(1,:);

%%

figure(3)

plot((C_Deaths_Since_L-S_Deaths_Since_L)/1000,'b-','LineWidth',2); hold on
plot((R_Deaths_C_Since_L(:,1)-R_Deaths_S_Since_L(:,1))/1000,'r-','LineWidth',1.5); hold on
plot((R_Deaths_C_Since_L(:,2)-R_Deaths_S_Since_L(:,2))/1000,'r--','LineWidth',1.5); hold on
plot((R_Deaths_C_Since_L(:,3)-R_Deaths_S_Since_L(:,3))/1000,'r.','LineWidth',1.5); hold on

yline(0,'LineWidth',1.5);
xlim([0 180])
ylim([-4.5 3])
ylabel('Cumulative difference in deaths (in thousands)','FontSize',12)
xlabel('Days since start of lockdown','FontSize',20)
legend('Specification B (Baseline Deaths)','Robustness B1 (w/o Belgium)','Robustness B2 (w/o Finland)','Robustness B3 (w/o Portugal)', 'Location', 'northeast','FontSize',20);
legend box off

set(gca,'Layer','top')
ax = gca
ax.YAxis.Exponent = 0;
ax.XGrid = 'off';
ax.YGrid = 'on';
fig=gcf;
    set(fig,'PaperOrientation','landscape');
    fig.PaperPositionMode = 'auto';
    set(gca,'FontSize',20)
print(gcf, ['../../Code_BDM_Feb_2021/Figures/Figure_2_D_resubmit', '.pdf'], '-bestfit', '-dpdf')
 

%% Output Tables
t=6;
L_D=zeros(t,1);
L_I=zeros(t,1);
L_D_S=zeros(t,1);
L_I_S=zeros(t,1);
L_D_C=zeros(t,1);
L_I_C=zeros(t,1);

L_D(1)=C_Deaths_Since_L(end)/S_Deaths_Since_L(end)-1;
L_I(1)=C_Infections_Since_L(end)/S_Infections_Since_L(end)-1;
L_D_S(1)=S_Deaths_Since_L(end);
L_I_S(1)=S_Infections_Since_L(end);
L_D_C(1)=C_Deaths_Since_L(end);
L_I_C(1)=C_Infections_Since_L(end);

L_D(5)=C_Deaths_Since_L_R1(end)/S_Deaths_Since_L_R1(end)-1;
L_I(5)=C_Infections_Since_L_R1(end)/S_Infections_Since_L_R1(end)-1;
L_D_S(5)=S_Deaths_Since_L_R1(end);
L_I_S(5)=S_Infections_Since_L_R1(end);
L_D_C(5)=C_Deaths_Since_L_R1(end);
L_I_C(5)=C_Infections_Since_L_R1(end);

L_D(6)=C_Deaths_Since_L_R2(end)/S_Deaths_Since_L_R2(end)-1;
L_I(6)=C_Infections_Since_L_R2(end)/S_Infections_Since_L_R2(end)-1;
L_D_S(6)=S_Deaths_Since_L_R2(end);
L_I_S(6)=S_Infections_Since_L_R2(end);
L_D_C(6)=C_Deaths_Since_L_R2(end);
L_I_C(6)=C_Infections_Since_L_R2(end);

for i=1:3

A=R_Deaths_S_Since_L(max(cumsum(~isnan(R_Deaths_S_Since_L(:,i)))),i);
B=R_Deaths_C_Since_L(max(cumsum(~isnan(R_Deaths_C_Since_L(:,i)))),i);
C=R_Infections_S_Since_L(max(cumsum(~isnan(R_Infections_S_Since_L(:,i)))),i);
D=R_Infections_C_Since_L(max(cumsum(~isnan(R_Infections_C_Since_L(:,i)))),i);

L_D(1+i)=B/A-1;
L_I(1+i)=D/C-1;
L_D_S(1+i)=A;
L_I_S(1+i)=C;
L_D_C(1+i)=B;
L_I_C(1+i)=D;
end


scenario = {'Baseline (Deaths)','Belgium Out','Finland Out','Ireland Out','Netherands Out','1 Death per 100.000'};
format short
T1 = table(L_D_S,L_D_C,L_D*100,'VariableNames',{'Deaths since Lockdown (Sweden)','Deaths since Lockdown (Counterfactual)','Less Deaths %'}, 'RowNames',{'Baseline (Deaths)','Belgium Out','Finland Out','Portugal Out','Robustness (1 dead in 1.000.000)','Robustness (1 dead in 50.000)'})
T2 = table(L_I_S,L_I_C,L_I*100,'VariableNames',{'Infections since Lockdown (Sweden)','Infections since Lockdown (Counterfactual)','Less Infections %'}, 'RowNames',{'Baseline (Deaths)','Belgium Out','Finland Out','Portugal Out','Robustness (1 dead in 1.000.000)','Robustness (1 dead in 50.000)'})




%% Compare Fit

%
load('RMSE')
RMSE_Sweden=RMSE;
RMSE_Sweden_post=RMSE_post;


load('RMSE_Placebo')

RMSE=[RMSE_Sweden RMSE];
RMSE_post=[RMSE_Sweden_post RMSE_post];
Ratio=RMSE_post./RMSE;
R=table(RMSE',RMSE_post',Ratio','VariableNames',{'RMSE (Treatment)','RMSE (Post Treatment)','Ratio (Deaths)'},'RowNames',...
    {'Sweden','Austria','Belgium','Denmark','Finland','France','Germany','Greece','Ireland','Italy','Netherlands','Norway','Portugal','Spain'})


