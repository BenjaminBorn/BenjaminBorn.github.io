clear; close all
addpath('../tools')
addpath('../tools/Simstools')
rng('default')
rng(3)

start_date = 1;
treatment_date = 14;
print_fig = 1; % save figure
main_var = 2; 
load_name = 'weigths_infections';

%% Get Data and stack it for synthetic control method
robustness_out_nr=zeros(6,1);
robustness_weights=zeros(13,13);
robustness_covar=zeros(3,13);
robustness_doppelganger=zeros(300,13);
robustness_doppelganger_infections=zeros(300,13);
robustness_Sweden=zeros(300,13);
robustness_Sweden_infections=zeros(300,13);
lockdown_dates_frame=zeros(13,2);
lockdown_start_end=zeros(13,2);
infections_difference=zeros(13,2);
deaths_difference=zeros(13,2);


%% Set Timeline
[data_raw, header_raw] = xlsread('../../Code_BDM_Feb_2021/Datasets/Baseline/Infections.xlsx',1,'A1:AD220');
timeline_all = 1 + data_raw(:, 1);
timeline = 1 + data_raw(find(data_raw(:, 1)==0):end, 1);
   
% Same Day 1 in Sweden as in Baseline 
for u=1:length(timeline)
timeline_dates(u)=datenum(2020,2,27)+timeline(u);
end
timeline_dates=timeline_dates';

%% Countires to be excluded in turn (robustness excercise) must be inserted into brackets
for i=[3 4 10 11];% 
    country_select = find(xlsread('../../Code_BDM_Feb_2021/Datasets/Characteristics/Country_Characteristics.xlsx',1,'B6:AD6')==1);
   [data,Names_Robust]=xlsread('../../Code_BDM_Feb_2021/Datasets/Characteristics/Country_Characteristics.xlsx',1,'B1:AD1');

   population_size = xlsread('../../Code_BDM_Feb_2021/Datasets/Characteristics/Country_Characteristics.xlsx',1,'A4:AD4');
   population_size=[1, population_size];
   
    % Iterate over countries to be excluded
    robustness_out_nr(i)=country_select(i);
    robustness_out_name=char(Names_Robust(country_select(i)));
    country_select(i)=[];
 
   [data_raw, header_raw] = xlsread('../../Code_BDM_Feb_2021/Datasets/Baseline/Infections.xlsx',1,'A1:AD220');
   data_all=data_raw;
   timeline_all = 1 + data_all(:, 1);
   data_raw=data_raw(find(data_raw(:, 1)==0):end,:);
   timeline = 1 + data_raw(:, 1);
   country_names = header_raw(1, 1 + country_select);
   data_treat_long = log(data_raw(:, 1 + country_select));
   data_all_long = log(data_all(:, 1 + country_select));
   data_treat = data_treat_long(timeline >= start_date & timeline < treatment_date, :, :); 
   data_treat_long(timeline < start_date, :) = [];
   plot_name = {'in'};
   print_name = '';%'in';
   load_dummy = 0;
      
forecastdates = [230,230];

% choose covariates to include
[data_raw, header_raw] = xlsread('../../Code_BDM_Feb_2021/Datasets/Characteristics/Country_Characteristics.xlsx',1,'A3:AD9');

header_raw=[header_raw(1:2,:);header_raw(6,:)];
data_raw=[data_raw(1:2,:);data_raw(6,:)];
covariate_names = header_raw(1:3,1)';
n_cov = length(covariate_names);
data_cov_long = [];
data_cov = [];
mean_cov = data_raw(:, country_select);


% Sweden is country 13 here
Scale_data=0.5*mean(data_treat_long(1:14,13));
Scale=mean_cov(:,13)/Scale_data;
mean_cov(1, :) = mean_cov(1, :)/Scale(1) ;
mean_cov(2, :) = mean_cov(2, :)/1000000;
mean_cov(3, :) = mean_cov(3, :)/Scale(3);
timeline(timeline < start_date) = [];
treatment_entry = find(timeline == treatment_date);

% deal with missing values
missing_covariates = find(any(any(isnan(data_cov_long),1),3));
missing_treatment = find(any(isnan(data_treat_long), 1));
missing_something = union(missing_covariates, missing_treatment);
if load_dummy==1
    load(load_name, 'missing_something');
end
data_treat(:, missing_something, :) = [];
data_treat_long(:, missing_something) = [];
mean_cov(:, missing_something) = [];
data_cov(:, missing_something, :) = [];
data_cov_long(:, missing_something, :) = [];

excluded_countries = country_names(missing_something)
country_names_save = country_names; % needed later
country_names(missing_something) = [];
n_countries = size(country_names, 2);
n_obs_pre = size(data_treat, 1);

%% Built Indices
index_tr  = find(strcmp(country_names(1,:),'Sweden'));
index_co = (1:n_countries)';
index_co(index_tr) = [];

%% Define matrices for matching in inner loop using all covariates
X0 = [data_treat(:, index_co); mean_cov(:, index_co)];
X1 = [data_treat(:, index_tr); mean_cov(:, index_tr)];
%% Define Matrices for outer loop optimization
Z0 = X0;
Z1 = X1;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Optimization
if load_dummy==0
options = optimset('MaxFunEvals', 20000, 'Display', 'iter', 'MaxIter', 20000, 'TolFun', 1e-6, 'TolX', 1e-3);

% Get Starting Values 
s = std([X1 X0],[],2);
s1 = s(1);
s2 = s(2:end);
v20 =((s1./s2).^2);
v20 = log(v20); %transform to unconstrained domain
% set csminwel options
H0 = 1e-2*eye(length(v20)); %Initial Hessian
crit = 1e-8; %Tolerance
nit = 10000;  %Number of iterations
count = 0;
err_count = 0;     

while count==err_count  
    try     
rng('default')
rng(1)               
[fminv1,v2] = csminwel(@loss_function_transformed,v20,H0,[],crit,nit,X1,X0,Z1,Z0);
fprintf('%15.4f',fminv1);
[v22,fminv,exitflag] = fminsearch('loss_function_transformed',v2,options,X1,X0,Z1,Z0);
v = [1;exp(v22)];  
fprintf('%15.4f',fminv);
    catch
    err_count=err_count+1;
    end
    count = count + 1;
end

% Now recover W-weights
D = diag(v);
H = X0'*D*X0;
H = (H+H')/2;
f = - X1'*D*X0;
options = optimoptions('quadprog', 'Display', 'off');
[w,fval,e]=quadprog(H,f,[],[],ones(1,size(X0,2)),1,zeros(size(X0,2),1),ones(size(X0,2),1),[],options);
w = abs(w);
else
    load(load_name, 'w');
end
%% plot preparations
Y0 = data_treat_long(:, index_co);
Y1 = data_treat_long(:, index_tr);
Y0_means = mean_cov(:, index_co);
Y1_means = mean_cov(:, index_tr);
%%% Show table with covariates and weights
Y0_means_comb = Y0_means * w;       
T = table(Y1_means, Y0_means_comb,'VariableNames',{'Sweden','Doppelganger'}, 'RowNames',covariate_names)
weights = w;
weights(abs(w)<10^-4)=0;
T = table(weights,'RowNames',country_names(index_co))

Y0_comb = Y0(:, :, 1) * w;
diff_mat = Y1 - Y0_comb;
errstd   = 2 * std(diff_mat(1:treatment_entry - 1, :), 1);
rmse = sqrt(mean(diff_mat(1:treatment_entry - 1, 1).^2))
Y0_plot = Y0_comb(:,1);
%% Lockdown Start
lockdown_raw = 1 + xlsread('../../Code_BDM_Feb_2021/Datasets/Characteristics/Country_Characteristics.xlsx',1,'B2:AD2');
lockdown_dates = lockdown_raw(1, country_select);
lockdown_dates(missing_something) = [];
lockdown_dates(index_tr) = [];
average_lockdown_date = floor(lockdown_dates * w);
lockdown_dates_frame(i,1)=timeline_dates(1)+average_lockdown_date;
lockdown_start_end(i,1)=average_lockdown_date;

%% Lockdown End
lockdown_end_raw = 1 + xlsread('../../Code_BDM_Feb_2021/Datasets/Characteristics/Country_Characteristics.xlsx',1,'B7:AD7');
lockdown_end_dates = lockdown_end_raw(1, country_select);
lockdown_end_dates(missing_something) = [];
lockdown_end_dates(index_tr) = [];
average_lockdown_end_date = floor(lockdown_end_dates * w);
lockdown_dates_frame(i,2)=timeline_dates(1)+average_lockdown_end_date;
lockdown_start_end(i,2)=average_lockdown_end_date;

%% wide-angle plot Deaths
plot_start = start_date;
plot_end   = datenum('01-sep-20','dd-mmm-yy')

figure

   jbfill(timeline_dates(timeline>=plot_start & timeline<forecastdates(1),1)', (Y0_plot(timeline>=plot_start & timeline<forecastdates(1),1) + errstd(1))',...
         (Y0_plot(timeline>=plot_start & timeline<forecastdates(1),1) - errstd(1))',[0.8,0.8,0.8],[0.8,0.8,0.8],1,1);  hold on


    ha = plot(timeline_dates(timeline>=plot_start & timeline<forecastdates(1),1), (Y1(timeline>=plot_start & timeline<forecastdates(1),1)),'b-', ...
    timeline_dates(timeline>=plot_start & timeline<forecastdates(1), 1), (Y0_plot(timeline>=plot_start & timeline<forecastdates(1),1)),'r--',...
    'LineWidth',1.5); hold on

patch([timeline_dates(1)+average_lockdown_date timeline_dates(1)+average_lockdown_end_date timeline_dates(1)+average_lockdown_end_date timeline_dates(1)+average_lockdown_date], [min(ylim) min(ylim) max(ylim) max(ylim)],[1 0 0],'EdgeColor','none','FaceAlpha',.05); hold on
  
xticks([datenum(2020,03,1) datenum(2020,04,1)...
datenum(2020,05,1) datenum(2020,06,01) ...
datenum(2020,07,01)  datenum(2020,08,01)...
datenum(2020,09,01) datenum(2020,10,01)]);
datetick('x','dd.mmm','keepticks')
box on

     ylabel('log (cumulative infections)');
xlim([timeline_dates(plot_start), plot_end])

legend(ha, 'Actual outcome', 'Counterfactual', 'Location', 'northwest');
legend box off 

set(gca,'Layer','top')
ax=gca
ax.YAxis.Exponent = 0;
ax.XGrid = 'off';
ax.YGrid = 'off';

if print_fig
    fig=gcf;
    set(fig,'PaperOrientation','landscape');
    fig.PaperPositionMode = 'auto'; 
    set(gca,'FontSize',22)
    print(gcf, ['../../Code_Final/Figures/','Infections_',robustness_out_name,'_out_I', '.pdf'], '-bestfit', '-dpdf')
end

%%  Plot for Infections on Basis of Death matching

plot_start = start_date;
[data_deaths, header_deaths] = xlsread('../../Code_BDM_Feb_2021/Datasets/Baseline/Deaths.xlsx',1,'A1:AD220');

country_deaths = header_deaths(1, 1 + country_select);
data_all_deaths=data_deaths;
data_deaths=data_deaths(find(data_deaths(:, 1)==0):end,:);
country_names = header_deaths(1, 1 + country_select);
data_deaths_long     = (data_deaths(:, 1 + country_select)+1);
data_all_deaths_long = (data_all_deaths(:, 1 + country_select)+1);
data_deaths = data_deaths_long(timeline >= start_date & timeline < treatment_date, :, :);
data_deaths_long(timeline < start_date, :) = [];
plot_deaths_name = {'de'};
print_deaths_name = '';%'in';
index_deaths  = find(strcmp(country_deaths(1,:),'Sweden'));
deaths_Sweden=data_deaths_long(:,index_deaths);

for jj=1:length(data_deaths_long);
   data_doppel(jj,1)=data_deaths_long(jj,1:12)*w;
end;

for jj=1:length(data_all_deaths_long);
   data_all_doppel(jj,1)=data_all_deaths_long(jj,1:12)*w;
end;

figure

plot_end   = datenum('01-sep-20','dd-mmm-yy');
 ha = plot(timeline_dates(timeline>=plot_start & timeline<forecastdates(1),1), (deaths_Sweden(timeline>=plot_start & timeline<forecastdates(1),1)),'b-', ...
    timeline_dates(timeline>=plot_start & timeline<forecastdates(1), 1), (data_doppel(timeline>=plot_start & timeline<forecastdates(1),1)),'r--',...
    'LineWidth',1.5); hold on

patch([timeline_dates(1)+average_lockdown_date timeline_dates(1)+average_lockdown_end_date timeline_dates(1)+average_lockdown_end_date timeline_dates(1)+average_lockdown_date], [min(ylim) min(ylim) max(ylim) max(ylim)],[1 0 0],'EdgeColor','none','FaceAlpha',.05); 

     ylabel('cumulative deaths');
legend( 'Actual outcome', 'Counterfactual', 'Location', 'northwest');
legend box off
xticks([datenum(2020,03,1)  datenum(2020,04,1) datenum(2020,05,1) datenum(2020,06,01) datenum(2020,07,01) datenum(2020,08,01) datenum(2020,09,01)]);
datetick('x','dd.mmm','keepticks')
xlim([timeline_dates(plot_start), plot_end]) 

box on  
set(gca,'Layer','top')
if print_fig
    fig=gcf;
    set(fig,'PaperOrientation','landscape');
    fig.PaperPositionMode = 'auto'; 
    set(gca,'FontSize',22)
    print(gcf, ['../../Code_BDM_Feb_2021/Figures/','Deaths_',robustness_out_name,'_out_I', '.pdf'], '-bestfit', '-dpdf')

end

%%  Store Results
START=find(timeline_all==average_lockdown_date);
for jj=1:length(data_deaths_long);
   data_doppel_report(jj,1)=exp(data_deaths_long(jj,1:12))*w;
end;
Y0_all = data_treat_long(:, index_co);
Y1_all = data_treat_long(:, index_tr);
Y0_comb_all = (Y0_all(:, :, 1)) * w;
 
robustness_doppelganger_deaths(1:find(timeline_dates==plot_end)-START+1,i)=(data_doppel(START:find(timeline_dates==plot_end)));
robustness_Sweden_deaths(1:find(timeline_dates==plot_end)-START+1,i)=(deaths_Sweden(START:find(timeline_dates==plot_end)));
robustness_doppelganger(1:find(timeline_dates==plot_end)-START+1,i)=exp(Y0_comb_all(START:find(timeline_dates==plot_end)));
robustness_Sweden(1:find(timeline_dates==plot_end)-START+1,i)=exp(Y1(START:find(timeline_dates==plot_end)));

%%   Store the weights calculated
robustness_weights(i:i,i)=NaN;
robustness_covar(:,i)=Y0_means_comb;
if i==1
robustness_weights(i+1:end,i)=weights;
else
robustness_weights(1:i-1,i)=weights(1:i-1);  
robustness_weights(i+1:end,i)=weights(i:end);  
country_select
end

end;

%%

country_select = find(xlsread('../../Code_BDM_Feb_2021/Datasets/Characteristics/Country_Characteristics.xlsx',1,'B6:AD6')==1);
[data,Names_Robust]=xlsread('../../Code_BDM_Feb_2021/Datasets/Characteristics/Country_Characteristics.xlsx',1,'B1:AD1');
Names=Names_Robust(country_select);
Names=Names(1:13)';
Out = array2table(robustness_weights,'VariableNames',Names')
Out.weight=Names;
Cov= array2table(robustness_covar);
Cov.Coviariate=covariate_names';
Out = movevars(Out,'weight','Before','Austria');
Cov = movevars(Cov,'Coviariate','Before','robustness_covar1');

writetable(Out, 'Robustness_weights.xlsx','Sheet','Weights');
writetable(Cov, 'Robustness_weights.xlsx','Sheet','Covariates');
Names_Out=Names';
close all;
save('Robustness_Results_Infections','robustness_doppelganger_deaths','robustness_doppelganger','robustness_Sweden_deaths','robustness_Sweden','lockdown_dates_frame','lockdown_start_end'); 
