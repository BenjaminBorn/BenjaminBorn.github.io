clear;
for main_var=2:3  
%clear; close all
addpath('../tools')
addpath('../tools/Simstools')
rng('default')
rng(1)  
start_date = 1;
treatment_date = 14;
print_fig = 1; % save figure
load_name = 'weigths_infections_Deaths';

%% Get Data and stack it for synthetic control method
country_select = find(xlsread('../../Code_BDM_Feb_2021/Datasets/Characteristics/Country_Characteristics_D.xlsx',1,'B6:AD6')==1);
population_size = xlsread('../../Code_BDM_Feb_2021/Datasets/Characteristics/Country_Characteristics_D.xlsx',1,'A4:AD4');
population_size=[1, population_size];
        
if main_var == 2
   [data_raw, header_raw] = xlsread('../../Code_BDM_Feb_2021/Datasets/Baseline/Deaths_D.xlsx',1,'A1:AD220');
   data_all=data_raw;
   timeline_all = 1 + data_all(:, 1);
   data_raw=data_raw(find(data_raw(:, 1)==0):end,:);
   timeline = 1 + data_raw(:, 1);
   country_names = header_raw(1, 1 + country_select);
   data_treat_long = log(data_raw(:, 1 + country_select));
   data_all_long = log(data_all(:, 1 + country_select));
   data_treat = data_treat_long(timeline >= start_date & timeline < treatment_date, :, :); 
   data_treat_long(timeline < start_date, :) = [];
   plot_name = {'in'};
   print_name = '';%'in';
   load_dummy = 0;
    
    
elseif main_var == 3  
   [data_raw, header_raw] = xlsread('../../Code_BDM_Feb_2021/Datasets/Baseline/Infections_D.xlsx',1,'A1:AD220');
   data_all=data_raw;
   timeline_all = 1 + data_all(:, 1);
   data_raw=data_raw(find(data_raw(:, 1)==0):end,:);
   timeline = 1 + data_raw(:, 1);
   country_names = header_raw(1, 1 + country_select);
   data_treat_long = (data_raw(:, 1 + country_select));
   data_all_long = (data_all(:, 1 + country_select));
   data_treat = data_treat_long(timeline >= start_date & timeline < treatment_date, :, :); 
   data_treat_long(timeline < start_date, :) = [];
   plot_name = {'de'};
   print_name = '';%'in';
   load_dummy = 1;
    
end

% set treatment variable
forecastdates = [250, 250];
% choose covariates to include
[data_raw, header_raw] = xlsread('../../Code_BDM_Feb_2021/Datasets/Characteristics/Country_Characteristics_D.xlsx',1,'A3:AD9');
header_raw=[header_raw(1:2,:);header_raw(6,:)];
data_raw=[data_raw(1:2,:);data_raw(6,:)];
covariate_names = header_raw(1:3,1)';
n_cov = length(covariate_names);
data_cov_long = [];
data_cov = [];
mean_cov = data_raw(:, country_select);

Scale_data=0.5*mean(data_treat_long(1:14,14));
Scale=mean_cov(:,14)/Scale_data;
mean_cov(1, :) = mean_cov(1, :)/Scale(1) ;
mean_cov(2, :) = mean_cov(2, :)/1000000;
mean_cov(3, :) = mean_cov(3, :)/Scale(3);
timeline(timeline < start_date) = [];
treatment_entry = find(timeline == treatment_date);
% deal with missing values
missing_covariates = find(any(any(isnan(data_cov_long),1),3));
missing_treatment = find(any(isnan(data_treat_long), 1));
missing_something = union(missing_covariates, missing_treatment);
if load_dummy==1
    load(load_name, 'missing_something');
end

data_treat(:, missing_something, :) = [];
data_treat_long(:, missing_something) = [];
mean_cov(:, missing_something) = [];
data_cov(:, missing_something, :) = [];
data_cov_long(:, missing_something, :) = [];
excluded_countries = country_names(missing_something)
country_names_save = country_names; % needed later
country_names(missing_something) = [];
n_countries = size(country_names, 2);
n_obs_pre = size(data_treat, 1);


%% Set Timeline
timeline_dates=[];
for i=1:length(timeline)
timeline_dates(i)=datenum(2020,3,24)+timeline(i);  % More than 1 per Million Deaths in Sweden on March 17
end
timeline_dates=timeline_dates';
%% Built Indices
index_tr  = find(strcmp(country_names(1,:),'Sweden'));
index_co = (1:n_countries)';
index_co(index_tr) = [];

%% Define matrices for matching in inner loop using all covariates
X0 = [data_treat(:, index_co); mean_cov(:, index_co)];
X1 = [data_treat(:, index_tr); mean_cov(:, index_tr)];

%% Define Matrices for outer loop optimization
 Z0 = X0;
 Z1 = X1;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Optimization
if load_dummy==0
options = optimset('MaxFunEvals', 20000, 'Display', 'iter', 'MaxIter', 20000, 'TolFun', 1e-6, 'TolX', 1e-3);
% Get Starting Values 
s = std([X1 X0],[],2);
s1 = s(1);
s2 = s(2:end);
v20 =((s1./s2).^2);
v20 = log(v20); %transform to unconstrained domain
% set csminwel options
H0 = 1e-2*eye(length(v20)); %Initial Hessian
crit = 1e-8; %Tolerance
nit = 10000;  %Number of iterations
count = 0;
err_count = 0;
     
rng('default')
rng(3)               
[fminv1,v2] = csminwel(@loss_function_transformed,v20,H0,[],crit,nit,X1,X0,Z1,Z0);
fprintf('%15.4f',fminv1);
[v22,fminv,exitflag] = fminsearch('loss_function_transformed',v2,options,X1,X0,Z1,Z0);
v = [1;exp(v22)];  
fprintf('%15.4f',fminv);

% Now recover W-weights
D = diag(v);
H = X0'*D*X0;
H = (H+H')/2;
f = - X1'*D*X0;
options = optimoptions('quadprog', 'Display', 'off');
[w,fval,e]=quadprog(H,f,[],[],ones(1,size(X0,2)),1,zeros(size(X0,2),1),ones(size(X0,2),1),[],options);
w = abs(w);
else
    load(load_name, 'w');
end
%% plot preparations

Y0 = data_treat_long(:, index_co);
Y1 = data_treat_long(:, index_tr);
Y0_means = mean_cov(:, index_co);
Y1_means = mean_cov(:, index_tr);
%%% Show table with covariates and weights
Y0_means_comb = Y0_means * w;       
Y0_means_comb(1)=Y0_means_comb(1)*Scale(1);
Y0_means_comb(3)=Y0_means_comb(3)*Scale(3);
Y0_means_comb(2)=Y0_means_comb(2);
Y1_means(1)=Y1_means(1)*Scale(1);
Y1_means(3)=Y1_means(3)*Scale(3);
Y1_means(2)=Y1_means(2);

T = table(Y1_means, Y0_means_comb,'VariableNames',{'Sweden','Doppelganger'}, 'RowNames',covariate_names)
weights = w;
weights(abs(w)<10^-4)=0;
T = table(weights,'RowNames',country_names(index_co))

Y0_comb = Y0(:, :, 1) * w;
diff_mat = Y1 - Y0_comb;
errstd   = 2 * std(diff_mat(1:treatment_entry - 1, :), 1);
rmse = sqrt(mean(diff_mat(1:treatment_entry - 1, 1).^2))
plot_end   = datenum('01-sep-20','dd-mmm-yy')

RMSE=rmse;
rmse_post = sqrt(mean((diff_mat(treatment_entry:find(timeline_dates==plot_end), 1)-diff_mat(treatment_entry)).^2));
RMSE_post=rmse_post;
Y0_plot = Y0_comb(:,1);
Y0_report=exp(data_treat_long(:, index_co))*w;
Y1_report= exp(data_treat_long(:, index_tr));
save('weigths_infections_Deaths','country_names','missing_something','w')
%% Lockdown Start Date
lockdown_raw = 1 + xlsread('../../Code_BDM_Feb_2021/Datasets/Characteristics/Country_Characteristics_D.xlsx',1,'B2:AD2');
lockdown_dates = lockdown_raw(1, country_select);
lockdown_dates(missing_something) = [];
lockdown_dates(index_tr) = [];
average_lockdown_date = floor(lockdown_dates * w);

%% Lockdown End Date (Shops reopening)
lockdown_end_raw = 1 + xlsread('../../Code_BDM_Feb_2021/Datasets/Characteristics/Country_Characteristics_D.xlsx',1,'B7:AD7');
lockdown_end_dates = lockdown_end_raw(1, country_select);
lockdown_end_dates(missing_something) = [];
lockdown_end_dates(index_tr) = [];
average_lockdown_end_date = floor(lockdown_end_dates * w);
%% SPECIFICATION BASELINE

plot_start = start_date;
plot_end   = datenum('01-sep-20','dd-mmm-yy')

if main_var == 3
 Y0_plot=Y0_plot/1000; 
 Y1=Y1/1000;   
end    

figure
%%% Error Bands
if main_var == 2
    jbfill(timeline_dates(timeline>=plot_start & timeline<forecastdates(1),1)', (Y0_plot(timeline>=plot_start & timeline<forecastdates(1),1)  + errstd(1))',...
    (Y0_plot(timeline>=plot_start & timeline<forecastdates(1),1) - errstd(1))',[0.8,0.8,0.8],[0.8,0.8,0.8],1,1);  
    hold on
end

%%% Sweden vs Counterfactual 
ha = plot(timeline_dates(timeline>=plot_start & timeline<forecastdates(1),1), (Y1(timeline>=plot_start & timeline<forecastdates(1),1)),'b-', ...
     timeline_dates(timeline>=plot_start & timeline<forecastdates(1), 1), (Y0_plot(timeline>=plot_start & timeline<forecastdates(1),1)),'r--',...
     'LineWidth',1.5);
     hold on

%%% Patch for lockdown period
patch([timeline_dates(1)+average_lockdown_date timeline_dates(1)+average_lockdown_end_date timeline_dates(1)+average_lockdown_end_date timeline_dates(1)+average_lockdown_date], [min(ylim) min(ylim) max(ylim) max(ylim)],[1 0 0],'EdgeColor','none','FaceAlpha',.05); hold on

%%% Date Ticks
xticks([datenum(2020,03,1) datenum(2020,04,1)...
datenum(2020,05,1) datenum(2020,06,01) ...
datenum(2020,07,01)  datenum(2020,08,01)...
datenum(2020,09,01) datenum(2020,10,01) datenum(2020,11,01)]);
datetick('x','dd.mmm','keepticks')
box on

%%% Legend and Labels
if main_var == 2
     ylabel('log (cumulative Deaths)'); 
else
  ylabel('cumulative Infections (in thousands)');
end

xlabel('Calendar time')
xlim([timeline_dates(plot_start), plot_end])
legend(ha, 'Actual outcome', 'Counterfactual', 'Location', 'northwest');
legend box off 

%%% Save Figure to pdf
set(gca,'Layer','top')
ax=gca
ax.YAxis.Exponent = 0;
ax.XGrid = 'off';
ax.YGrid = 'off';
fig=gcf;
set(fig,'PaperOrientation','landscape');
fig.PaperPositionMode = 'auto';
set(gca,'FontSize',20)
 
if main_var==2
print(gcf, ['../../Code_BDM_Feb_2021/Figures/Deaths_B_D', '.pdf'], '-bestfit', '-dpdf','-r1200')
else
print(gcf, ['../../Code_BDM_Feb_2021/Figures/Infections_B_D', '.pdf'], '-bestfit', '-dpdf')
end
  

if main_var == 3
 Y0_plot=Y0_plot*1000; 
 Y1=Y1*1000;   
end  
%% Data before matching period included (since Lockdown in Counterfactual might start prior)

S_B=average_lockdown_date;
E_B=average_lockdown_end_date;

START=find(timeline_all==S_B);  
END=find(timeline_dates == plot_end);
    
Y0_all = data_all_long(:, index_co);
Y1_all = data_all_long(:, index_tr);

%%% Show table with covariates and weights
Y0_comb_all = Y0_all(:, :, 1) * w;
  

%% Save Reuslts

if main_var==2
    
   Sweden=exp(Y1_all(START:END));
   Counterfactual=exp(Y0_comb_all(START:END)); 
    
       save('Sweden_Excess_Deaths_Baseline_D','Sweden','Counterfactual','S_B','E_B'); 
       save('RMSE','RMSE','RMSE_post'); 
elseif main_var==3
    
    Sweden=(Y1_all(START:END));
    Counterfactual=(Y0_comb_all(START:END));
       save('Sweden_Excess_Infections_Baseline_D','Sweden','Counterfactual','S_B','E_B');  
end

end