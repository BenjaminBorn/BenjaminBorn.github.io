clear all; close all;
run('SCM_lockdown_Baseline_Infections.m')
run('SCM_lockdown_Baseline_Infections_I1.m')
run('SCM_lockdown_Baseline_Infections_I2.m')
run('SCM_lockdown_Baseline_placebo_Infections.m')
run('SCM_lockdown_robustness_Infections.m')

%%
countryex=[ 3 4  10 11];

load('Robustness_Results_Infections')
load('Sweden_Excess_Deaths_Baseline_I')
Sweden_D=Sweden;
Counterfactual_D=Counterfactual;
load('Sweden_Excess_Infections_Baseline_I')
Sweden_I=Sweden;
Counterfactual_I=Counterfactual;

load('Sweden_Excess_Deaths_Baseline_I1')
Sweden_D_I1=Sweden;
Counterfactual_D_I1=Counterfactual;
load('Sweden_Excess_Infections_Baseline_I1')
Sweden_I_I1=Sweden;
Counterfactual_I_I1=Counterfactual;


load('Sweden_Excess_Deaths_Baseline_I2')
Sweden_D_I2=Sweden;
Counterfactual_D_I2=Counterfactual;
load('Sweden_Excess_Infections_Baseline_I2')
Sweden_I_I2=Sweden;
Counterfactual_I_I2=Counterfactual;

robustness_doppelganger(robustness_doppelganger==0) = NaN;
robustness_doppelganger_deaths(robustness_doppelganger_deaths==0) = NaN;
robustness_Sweden(robustness_Sweden==0) = NaN;
robustness_Sweden_deaths(robustness_Sweden_deaths==0) = NaN;

robustness_doppelganger=robustness_doppelganger(:,countryex);
robustness_doppelganger_deaths=robustness_doppelganger_deaths(:,countryex);
robustness_Sweden=robustness_Sweden(:,countryex);
robustness_Sweden_deaths=robustness_Sweden_deaths(:,countryex);
%%
Counterfactual_Deaths_Level=(Counterfactual_D);
Sweden_Deaths_Level=(Sweden_D);

Counterfactual_Infections_Level=(Counterfactual_I);
Sweden_Infections_Level=(Sweden_I);

Counterfactual_Deaths_Level_I1=(Counterfactual_D_I1);
Sweden_Deaths_Level_I1=(Sweden_D_I1);

Counterfactual_Infections_Level_I1=(Counterfactual_I_I1);
Sweden_Infections_Level_I1=(Sweden_I_I1);


Counterfactual_Deaths_Level_I2=(Counterfactual_D_I2);
Sweden_Deaths_Level_I2=(Sweden_D_I2);

Counterfactual_Infections_Level_I2=(Counterfactual_I_I2);
Sweden_Infections_Level_I2=(Sweden_I_I2);


b =robustness_doppelganger_deaths(any(robustness_doppelganger_deaths ~= NaN,2),:);
R_Deaths_C =(b(:,any(b ~= NaN,1)));
R_Deaths_C(R_Deaths_C==-Inf) = 0;

b =robustness_doppelganger(any(robustness_doppelganger ~= NaN,2),:);
R_Infections_C =(b(:,any(b ~= NaN,1)));

b =robustness_Sweden_deaths(any(robustness_Sweden_deaths ~= NaN,2),:);
R_Deaths_S =(b(:,any(b ~= NaN,1)));

b =robustness_Sweden(any(robustness_Sweden ~= NaN,2),:);
R_Infections_S =(b(:,any(b ~= NaN,1)));


%%  Absolute Numbers since Start of Lockdown

S_Deaths_Since_L=Sweden_Deaths_Level-Sweden_Deaths_Level(1);
C_Deaths_Since_L=Counterfactual_Deaths_Level-Counterfactual_Deaths_Level(1);

S_Infections_Since_L=Sweden_Infections_Level-Sweden_Infections_Level(1);
C_Infections_Since_L=Counterfactual_Infections_Level-Counterfactual_Infections_Level(1);

S_Deaths_Since_L_I1=Sweden_Deaths_Level_I1-Sweden_Deaths_Level_I1(1);
C_Deaths_Since_L_I1=Counterfactual_Deaths_Level_I1-Counterfactual_Deaths_Level_I1(1);

S_Infections_Since_L_I1=Sweden_Infections_Level_I1-Sweden_Infections_Level_I1(1);
C_Infections_Since_L_I1=Counterfactual_Infections_Level_I1-Counterfactual_Infections_Level_I1(1);


S_Deaths_Since_L_I2=Sweden_Deaths_Level_I2-Sweden_Deaths_Level_I2(1);
C_Deaths_Since_L_I2=Counterfactual_Deaths_Level_I2-Counterfactual_Deaths_Level_I2(1);

S_Infections_Since_L_I2=Sweden_Infections_Level_I2-Sweden_Infections_Level_I2(1);
C_Infections_Since_L_I2=Counterfactual_Infections_Level_I2-Counterfactual_Infections_Level_I2(1);

R_Deaths_C_Since_L=R_Deaths_C-R_Deaths_C(1,:);
R_Infections_C_Since_L=R_Infections_C-R_Infections_C(1,:);

R_Deaths_S_Since_L=R_Deaths_S-R_Deaths_S(1,:);
R_Infections_S_Since_L=R_Infections_S-R_Infections_S(1,:);

%%
figure(4)
plot((C_Infections_Since_L-S_Infections_Since_L)/1000,'b-','LineWidth',2); hold on
plot((R_Infections_C_Since_L(:,1)-R_Infections_S_Since_L(:,1))/1000,'r-','LineWidth',2); hold on
plot((R_Infections_C_Since_L(:,2)-R_Infections_S_Since_L(:,2))/1000,'r-.','LineWidth',2); hold on
plot((R_Infections_C_Since_L(:,3)-R_Infections_S_Since_L(:,3))/1000,'r--','LineWidth',2); hold on
plot((R_Infections_C_Since_L(:,4)-R_Infections_S_Since_L(:,4))/1000,'r-.','LineWidth',2); hold on

yline(0,'LineWidth',1.5);
xlim([0 180])
ylim([-80 50])
ylabel('Cumulative difference in infections (in thousands)','FontSize',12)
xlabel('Days since start of lockdown','FontSize',20)
legend('Specification A (Baseline Infections)','Robustness A1 (w/o Denmark)','Robustness A2 (w/o Finland)','Robustness A3 (w/o Netherlands)','Robustness A4 (w/o Norway)', 'Location', 'northeast', 'FontSize',20);
legend box off

set(gca,'Layer','top')
ax = gca
ax.YAxis.Exponent = 0;
ax.XGrid = 'off';
ax.YGrid = 'on';
fig=gcf;
    set(fig,'PaperOrientation','landscape');
    fig.PaperPositionMode = 'auto';
    set(gca,'FontSize',20)
print(gcf, ['../../Code_BDM_Feb_2021/Figures/Figure_2_I', '.pdf'], '-bestfit', '-dpdf')
 

%% Output Tables
t=7;
L_D=zeros(t,1);
L_I=zeros(t,1);
L_D_S=zeros(t,1);
L_I_S=zeros(t,1);
L_D_C=zeros(t,1);
L_I_C=zeros(t,1);

L_D(1)=C_Deaths_Since_L(end)/S_Deaths_Since_L(end)-1;
L_I(1)=C_Infections_Since_L(end)/S_Infections_Since_L(end)-1;
L_D_S(1)=S_Deaths_Since_L(end);
L_I_S(1)=S_Infections_Since_L(end);
L_D_C(1)=C_Deaths_Since_L(end);
L_I_C(1)=C_Infections_Since_L(end);

L_D(6)=C_Deaths_Since_L_I1(end)/S_Deaths_Since_L_I1(end)-1;
L_I(6)=C_Infections_Since_L_I1(end)/S_Infections_Since_L_I1(end)-1;
L_D_S(6)=S_Deaths_Since_L_I1(end);
L_I_S(6)=S_Infections_Since_L_I1(end);
L_D_C(6)=C_Deaths_Since_L_I1(end);
L_I_C(6)=C_Infections_Since_L_I1(end);

L_D(7)=C_Deaths_Since_L_I2(end)/S_Deaths_Since_L_I2(end)-1;
L_I(7)=C_Infections_Since_L_I2(end)/S_Infections_Since_L_I2(end)-1;
L_D_S(7)=S_Deaths_Since_L_I2(end);
L_I_S(7)=S_Infections_Since_L_I2(end);
L_D_C(7)=C_Deaths_Since_L_I2(end);
L_I_C(7)=C_Infections_Since_L_I2(end);


for i=1:4

A=R_Deaths_S_Since_L(max(cumsum(~isnan(R_Deaths_S_Since_L(:,i)))),i);
B=R_Deaths_C_Since_L(max(cumsum(~isnan(R_Deaths_C_Since_L(:,i)))),i);
C=R_Infections_S_Since_L(max(cumsum(~isnan(R_Infections_S_Since_L(:,i)))),i);
D=R_Infections_C_Since_L(max(cumsum(~isnan(R_Infections_C_Since_L(:,i)))),i);

L_D(1+i)=B/A-1;
L_I(1+i)=D/C-1;
L_D_S(1+i)=A;
L_I_S(1+i)=C;
L_D_C(1+i)=B;
L_I_C(1+i)=D;

end
scenario = {'Baseline (Infections)','Austria Out','Belgium Out','Finland Out','Italy Out','Norway Out','1 Death per 100.000','1 Death per 50.000'};

T1 = table(L_D_S,L_D_C,L_D*100,'VariableNames',{'Deaths since Lockdown (Sweden)','Deaths since Lockdown (Counterfactual)','Less Deaths %'}, 'RowNames',{'Baseline (Infections)','Denmark Out','Finland Out','Netherlands Out','Norway Out','1 Infected per 5.000.000','1 Infected per 100.000'})
T2 = table(L_I_S,L_I_C,L_I*100,'VariableNames',{'Infections since Lockdown (Sweden)','Infections since Lockdown (Counterfactual)','Less Infections %'}, 'RowNames',{'Baseline (Infections)','Denmark Out','Finland Out','Netherlands Out','Norway Out','1 Infected per 5.000.000','1 Infected per 100.000'})
 

%% Compare Fit
load('RMSE_Inf')
RMSE_Sweden=RMSE;
RMSE_Sweden_post=RMSE_post;

load('RMSE_Placebo_Inf')
RMSE=[RMSE_Sweden RMSE];
RMSE_post=[RMSE_Sweden_post RMSE_post];
Ratio=RMSE_post./RMSE;
R=table(RMSE',RMSE_post',Ratio','VariableNames',{'RMSE (Treatment)','RMSE (Post Treatment)','Ratio (Infections)'},'RowNames',...
    {'Sweden','Austria','Belgium','Denmark','Finland','France','Germany','Greece','Ireland','Italy','Netherlands','Norway','Portugal','Spain'})


